# ProGuard rules for Mutarjimi

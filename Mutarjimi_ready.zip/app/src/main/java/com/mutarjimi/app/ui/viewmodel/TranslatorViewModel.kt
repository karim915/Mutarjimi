package com.mutarjimi.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.mutarjimi.app.data.local.AppDatabase
import com.mutarjimi.app.data.local.TranslationEntity
import com.mutarjimi.app.data.mlkit.TranslationDirection
import com.mutarjimi.app.data.mlkit.TranslationHelper
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class TranslatorUiState(
    val inputText: String = "",
    val translatedText: String = "",
    val direction: TranslationDirection = TranslationDirection.AR_TO_FR,
    val autoDetectedLabel: String? = null,
    val modelsReady: Boolean = false,
    val isDownloadingModels: Boolean = false,
    val isTranslating: Boolean = false,
    val currentRecordId: Long? = null,
    val isCurrentFavorite: Boolean = false,
    val errorMessage: String? = null
)

class TranslatorViewModel(application: Application) : AndroidViewModel(application) {

    private val translationHelper = TranslationHelper()
    private val dao = AppDatabase.getInstance(application).translationDao()

    private val _uiState = MutableStateFlow(TranslatorUiState())
    val uiState: StateFlow<TranslatorUiState> = _uiState.asStateFlow()

    val historyList: StateFlow<List<TranslationEntity>> = dao.getAllHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val favoritesList: StateFlow<List<TranslationEntity>> = dao.getFavorites()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var translateJob: Job? = null
    private var saveHistoryJob: Job? = null

    init {
        checkAndPrepareModels()
    }

    fun checkAndPrepareModels() {
        viewModelScope.launch {
            _uiState.update { it.copy(isDownloadingModels = true, errorMessage = null) }
            try {
                val alreadyDownloaded = translationHelper.areModelsDownloaded()
                if (!alreadyDownloaded) {
                    translationHelper.downloadModelsIfNeeded()
                }
                _uiState.update {
                    it.copy(modelsReady = true, isDownloadingModels = false)
                }
                if (_uiState.value.inputText.isNotBlank()) {
                    performTranslation(_uiState.value.inputText, _uiState.value.direction)
                }
            } catch (e: Exception) {
                _uiState.update {
                    it.copy(
                        modelsReady = false,
                        isDownloadingModels = false,
                        errorMessage = "تعذّر تحميل نماذج الترجمة. تأكد من الاتصال بالإنترنت في المرة الأولى فقط."
                    )
                }
            }
        }
    }

    fun onInputTextChanged(newText: String) {
        _uiState.update {
            it.copy(
                inputText = newText,
                errorMessage = null,
                currentRecordId = null,
                isCurrentFavorite = false
            )
        }
        translateJob?.cancel()
        saveHistoryJob?.cancel()

        if (newText.isBlank()) {
            _uiState.update {
                it.copy(translatedText = "", isTranslating = false, autoDetectedLabel = null)
            }
            return
        }

        translateJob = viewModelScope.launch {
            delay(300L)
            val detected = try {
                translationHelper.detectLanguage(newText)
            } catch (_: Exception) {
                null
            }

            val updatedDirection = when (detected) {
                "ar" -> TranslationDirection.AR_TO_FR
                "fr" -> TranslationDirection.FR_TO_AR
                else -> _uiState.value.direction
            }

            val detectedLabel = when (detected) {
                "ar" -> "تم التعرّف تلقائياً: العربية"
                "fr" -> "تم التعرّف تلقائياً: الفرنسية"
                else -> null
            }

            _uiState.update {
                it.copy(direction = updatedDirection, autoDetectedLabel = detectedLabel)
            }

            if (_uiState.value.modelsReady) {
                performTranslation(newText, updatedDirection)
            }
        }
    }

    fun swapDirection() {
        val current = _uiState.value
        val newDirection = if (current.direction == TranslationDirection.AR_TO_FR) {
            TranslationDirection.FR_TO_AR
        } else {
            TranslationDirection.AR_TO_FR
        }

        val swappedInput = current.translatedText
        _uiState.update {
            it.copy(
                direction = newDirection,
                inputText = swappedInput,
                translatedText = if (swappedInput.isNotBlank()) current.inputText else "",
                autoDetectedLabel = null,
                currentRecordId = null,
                isCurrentFavorite = false
            )
        }

        if (swappedInput.isNotBlank() && current.modelsReady) {
            viewModelScope.launch {
                performTranslation(swappedInput, newDirection)
            }
        }
    }

    fun clearText() {
        translateJob?.cancel()
        saveHistoryJob?.cancel()
        _uiState.update {
            it.copy(
                inputText = "",
                translatedText = "",
                isTranslating = false,
                autoDetectedLabel = null,
                currentRecordId = null,
                isCurrentFavorite = false,
                errorMessage = null
            )
        }
    }

    private suspend fun performTranslation(text: String, direction: TranslationDirection) {
        _uiState.update { it.copy(isTranslating = true, errorMessage = null) }
        try {
            val result = translationHelper.translate(text, direction)
            _uiState.update { it.copy(translatedText = result, isTranslating = false) }
            scheduleHistorySave(text.trim(), result.trim(), direction)
        } catch (e: Exception) {
            _uiState.update {
                it.copy(
                    isTranslating = false,
                    errorMessage = "حدث خطأ أثناء الترجمة: ${e.localizedMessage ?: ""}"
                )
            }
        }
    }

    private fun scheduleHistorySave(
        source: String,
        translated: String,
        direction: TranslationDirection
    ) {
        if (source.isBlank() || translated.isBlank()) return
        saveHistoryJob?.cancel()
        saveHistoryJob = viewModelScope.launch {
            delay(1500L)
            saveOrUpdateRecord(source, translated, direction, forceFavorite = null)
        }
    }

    private suspend fun saveOrUpdateRecord(
        source: String,
        translated: String,
        direction: TranslationDirection,
        forceFavorite: Boolean?
    ): Long {
        val existing = dao.findExisting(source, direction.name)
        return if (existing != null) {
            val fav = forceFavorite ?: existing.isFavorite
            dao.updateTimestampAndText(existing.id, translated, System.currentTimeMillis())
            if (forceFavorite != null) {
                dao.updateFavorite(existing.id, fav)
            }
            _uiState.update { it.copy(currentRecordId = existing.id, isCurrentFavorite = fav) }
            existing.id
        } else {
            val fav = forceFavorite ?: false
            val newId = dao.insert(
                TranslationEntity(
                    sourceText = source,
                    translatedText = translated,
                    direction = direction.name,
                    isFavorite = fav
                )
            )
            _uiState.update { it.copy(currentRecordId = newId, isCurrentFavorite = fav) }
            newId
        }
    }

    fun toggleCurrentFavorite() {
        val current = _uiState.value
        val source = current.inputText.trim()
        val translated = current.translatedText.trim()
        if (source.isBlank() || translated.isBlank()) return

        saveHistoryJob?.cancel()
        val newFav = !current.isCurrentFavorite
        viewModelScope.launch {
            if (current.currentRecordId != null) {
                dao.updateFavorite(current.currentRecordId, newFav)
                _uiState.update { it.copy(isCurrentFavorite = newFav) }
            } else {
                saveOrUpdateRecord(source, translated, current.direction, forceFavorite = newFav)
            }
        }
    }

    fun toggleItemFavorite(item: TranslationEntity) {
        viewModelScope.launch {
            val newFav = !item.isFavorite
            dao.updateFavorite(item.id, newFav)
            if (_uiState.value.currentRecordId == item.id) {
                _uiState.update { it.copy(isCurrentFavorite = newFav) }
            }
        }
    }

    fun deleteHistoryItem(id: Long) {
        viewModelScope.launch {
            dao.deleteById(id)
            if (_uiState.value.currentRecordId == id) {
                _uiState.update { it.copy(currentRecordId = null, isCurrentFavorite = false) }
            }
        }
    }

    fun clearAllHistory() {
        viewModelScope.launch {
            dao.clearAll()
            _uiState.update { it.copy(currentRecordId = null, isCurrentFavorite = false) }
        }
    }

    fun loadFromHistory(item: TranslationEntity) {
        translateJob?.cancel()
        saveHistoryJob?.cancel()
        val dir = if (item.direction == TranslationDirection.FR_TO_AR.name) {
            TranslationDirection.FR_TO_AR
        } else {
            TranslationDirection.AR_TO_FR
        }
        _uiState.update {
            it.copy(
                inputText = item.sourceText,
                translatedText = item.translatedText,
                direction = dir,
                currentRecordId = item.id,
                isCurrentFavorite = item.isFavorite,
                autoDetectedLabel = null,
                errorMessage = null
            )
        }
    }

    override fun onCleared() {
        super.onCleared()
        translationHelper.close()
    }
}

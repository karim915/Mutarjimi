package com.mutarjimi.app.util

import android.content.Context
import android.speech.tts.TextToSpeech
import android.widget.Toast
import java.util.Locale

class TextToSpeechHelper(private val context: Context) {

    private var tts: TextToSpeech? = null
    private var isReady = false

    init {
        tts = TextToSpeech(context.applicationContext) { status ->
            isReady = (status == TextToSpeech.SUCCESS)
        }
    }

    fun speak(text: String, languageCode: String) {
        if (text.isBlank()) return
        if (!isReady) {
            Toast.makeText(context, "محرك النطق غير جاهز بعد", Toast.LENGTH_SHORT).show()
            return
        }

        val locale = if (languageCode == "fr") Locale.FRENCH else Locale("ar")
        val result = tts?.setLanguage(locale)

        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            Toast.makeText(
                context,
                "حزمة النطق الصوتي لهذه اللغة غير مثبتة في إعدادات الهاتف",
                Toast.LENGTH_LONG
            ).show()
            return
        }

        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "mutarjimi_tts")
    }

    fun stop() {
        tts?.stop()
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}

package com.mutarjimi.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "translations")
data class TranslationEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val sourceText: String,
    val translatedText: String,
    val direction: String,
    val isFavorite: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

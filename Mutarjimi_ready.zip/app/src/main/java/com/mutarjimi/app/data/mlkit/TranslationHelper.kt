package com.mutarjimi.app.data.mlkit

import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.languageid.LanguageIdentificationOptions
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.TranslateRemoteModel
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.Translator
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.tasks.await

enum class TranslationDirection(val sourceCode: String, val targetCode: String) {
    AR_TO_FR(TranslateLanguage.ARABIC, TranslateLanguage.FRENCH),
    FR_TO_AR(TranslateLanguage.FRENCH, TranslateLanguage.ARABIC)
}

class TranslationHelper {

    private val languageIdentifier = LanguageIdentification.getClient(
        LanguageIdentificationOptions.Builder()
            .setConfidenceThreshold(0.35f)
            .build()
    )

    private val arToFrTranslator: Translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.ARABIC)
            .setTargetLanguage(TranslateLanguage.FRENCH)
            .build()
    )

    private val frToArTranslator: Translator = Translation.getClient(
        TranslatorOptions.Builder()
            .setSourceLanguage(TranslateLanguage.FRENCH)
            .setTargetLanguage(TranslateLanguage.ARABIC)
            .build()
    )

    suspend fun areModelsDownloaded(): Boolean {
        val modelManager = RemoteModelManager.getInstance()
        val downloadedModels = modelManager.getDownloadedModels(TranslateRemoteModel::class.java).await()
        val codes = downloadedModels.map { it.language }
        return codes.contains(TranslateLanguage.ARABIC) && codes.contains(TranslateLanguage.FRENCH)
    }

    suspend fun downloadModelsIfNeeded() {
        val conditions = DownloadConditions.Builder().build()
        arToFrTranslator.downloadModelIfNeeded(conditions).await()
        frToArTranslator.downloadModelIfNeeded(conditions).await()
    }

    suspend fun detectLanguage(text: String): String? {
        if (text.isBlank()) return null
        val code = languageIdentifier.identifyLanguage(text).await()
        return if (code == "ar" || code == "fr") code else null
    }

    suspend fun translate(text: String, direction: TranslationDirection): String {
        if (text.isBlank()) return ""
        val translator = when (direction) {
            TranslationDirection.AR_TO_FR -> arToFrTranslator
            TranslationDirection.FR_TO_AR -> frToArTranslator
        }
        return translator.translate(text).await()
    }

    fun close() {
        languageIdentifier.close()
        arToFrTranslator.close()
        frToArTranslator.close()
    }
}
